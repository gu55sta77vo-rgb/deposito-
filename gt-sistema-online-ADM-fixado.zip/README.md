# GT Sistema Online

Versão web centralizada do GT Sistema.

## Acesso ADM
- Login: `ADM`
- Senha: `1234`

As credenciais do ADM estão definidas diretamente em `server.js`, portanto a hospedagem não depende das variáveis `ADMIN_USER` e `ADMIN_PASSWORD`.

## Executar
```bash
npm install
npm start
```

Abra `http://localhost:3000`.

## Publicação
O projeto inclui `Dockerfile` e `render.yaml`. O banco SQLite fica em `/app/data/gt.sqlite` com disco persistente configurado no Render.

## Observação
Este é um simulador/sistema de votação e não um sistema eleitoral oficial.
