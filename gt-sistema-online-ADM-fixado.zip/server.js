import express from 'express';
import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const DB_PATH = process.env.DB_PATH || path.join(__dirname, 'data', 'gt.sqlite');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
// Credenciais do administrador definidas diretamente no servidor.
// Login: ADM | Senha: 1234
const ADMIN_USER = 'ADM';
const ADMIN_PASSWORD = '1234';
const SESSION_DAYS = Number(process.env.SESSION_DAYS || 7);

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS candidates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  number TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  party TEXT DEFAULT '',
  photo TEXT DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS votes (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  candidate_id INTEGER,
  cpf_hash TEXT NOT NULL UNIQUE,
  is_blank INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(candidate_id) REFERENCES candidates(id) ON DELETE RESTRICT
);
CREATE TABLE IF NOT EXISTS sessions (
  token_hash TEXT PRIMARY KEY,
  expires_at INTEGER NOT NULL
);
`);

const count = db.prepare('SELECT COUNT(*) AS n FROM candidates').get().n;
if (count === 0) {
  const insert = db.prepare('INSERT INTO candidates (number,name,party) VALUES (?,?,?)');
  const seed = db.transaction(() => {
    insert.run('10','Ana Silva','Partido A');
    insert.run('20','Bruno Santos','Partido B');
    insert.run('30','Carlos Lima','Partido C');
    insert.run('40','Daniela Souza','Partido D');
  });
  seed();
}

app.use(express.json({ limit: '3mb' }));
app.use(express.static(path.join(__dirname, 'public')));

function normalizeCPF(value){ return String(value || '').replace(/\D/g,'').slice(0,11); }
function validCPF(cpf){
  const d=normalizeCPF(cpf);
  if(d.length!==11 || /^(\d)\1{10}$/.test(d)) return false;
  let sum=0; for(let i=0;i<9;i++) sum+=Number(d[i])*(10-i);
  let r=(sum*10)%11; if(r===10) r=0; if(r!==Number(d[9])) return false;
  sum=0; for(let i=0;i<10;i++) sum+=Number(d[i])*(11-i);
  r=(sum*10)%11; if(r===10) r=0; return r===Number(d[10]);
}
function cpfHash(cpf){ return crypto.createHash('sha256').update(normalizeCPF(cpf)).digest('hex'); }
function passwordOk(input, expected){
  const a=Buffer.from(String(input||'')); const b=Buffer.from(String(expected||''));
  return a.length===b.length && crypto.timingSafeEqual(a,b);
}
function newToken(){ return crypto.randomBytes(32).toString('hex'); }
function tokenHash(token){ return crypto.createHash('sha256').update(token).digest('hex'); }
function setSessionCookie(res, token){
  const maxAge=SESSION_DAYS*24*60*60*1000;
  const secure=process.env.NODE_ENV==='production' ? '; Secure' : '';
  res.setHeader('Set-Cookie', `gt_session=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${Math.floor(maxAge/1000)}${secure}`);
}
function clearSessionCookie(res){ res.setHeader('Set-Cookie','gt_session=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0'); }
function getCookie(req,name){
  const raw=req.headers.cookie||'';
  const part=raw.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='));
  return part ? decodeURIComponent(part.slice(name.length+1)) : '';
}
function requireAdmin(req,res,next){
  const token=getCookie(req,'gt_session');
  if(!token) return res.status(401).json({error:'Não autenticado'});
  const row=db.prepare('SELECT token_hash,expires_at FROM sessions WHERE token_hash=?').get(tokenHash(token));
  if(!row || row.expires_at < Date.now()) { if(row) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(row.token_hash); return res.status(401).json({error:'Sessão expirada'}); }
  next();
}
function publicCandidates(){
  return db.prepare('SELECT id,number,name,party,photo FROM candidates ORDER BY CAST(number AS INTEGER)').all();
}
function isSafePhoto(photo){ return !photo || (typeof photo==='string' && photo.length <= 2_500_000 && /^data:image\/(png|jpeg|jpg|webp);base64,/i.test(photo)); }

app.get('/api/health',(req,res)=>res.json({ok:true}));
app.get('/api/candidates',(req,res)=>res.json({candidates:publicCandidates()}));

app.post('/api/voting/start',(req,res)=>{
  const cpf=normalizeCPF(req.body?.cpf);
  if(!validCPF(cpf)) return res.status(400).json({error:'Digite um CPF válido.'});
  const used=db.prepare('SELECT 1 FROM votes WHERE cpf_hash=?').get(cpfHash(cpf));
  if(used) return res.status(409).json({error:'Este CPF já realizou uma votação.'});
  res.json({ok:true});
});

app.post('/api/voting/confirm',(req,res)=>{
  const cpf=normalizeCPF(req.body?.cpf); const number=String(req.body?.number||''); const blank=Boolean(req.body?.blank);
  if(!validCPF(cpf)) return res.status(400).json({error:'CPF inválido.'});
  if(!blank && !/^\d{2}$/.test(number)) return res.status(400).json({error:'Número de candidato inválido.'});
  const hash=cpfHash(cpf);
  try {
    const tx=db.transaction(()=>{
      if(db.prepare('SELECT 1 FROM votes WHERE cpf_hash=?').get(hash)) throw new Error('DUPLICATE');
      let candidateId=null;
      if(!blank){ const c=db.prepare('SELECT id FROM candidates WHERE number=?').get(number); if(!c) throw new Error('CANDIDATE'); candidateId=c.id; }
      db.prepare('INSERT INTO votes(candidate_id,cpf_hash,is_blank) VALUES (?,?,?)').run(candidateId,hash,blank?1:0);
    });
    tx();
  } catch(e){
    if(e.message==='DUPLICATE') return res.status(409).json({error:'Este CPF já realizou uma votação.'});
    if(e.message==='CANDIDATE') return res.status(400).json({error:'Número não cadastrado.'});
    if(String(e.code||'').includes('SQLITE_CONSTRAINT')) return res.status(409).json({error:'Votação não registrada: tente novamente.'});
    console.error(e); return res.status(500).json({error:'Erro ao registrar voto.'});
  }
  res.json({ok:true});
});

app.post('/api/admin/login',(req,res)=>{
  const user=String(req.body?.user||''); const password=String(req.body?.password||'');
  if(user!==ADMIN_USER || !passwordOk(password,ADMIN_PASSWORD)) return res.status(401).json({error:'Login ou senha inválidos.'});
  const token=newToken();
  db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());
  db.prepare('INSERT INTO sessions(token_hash,expires_at) VALUES(?,?)').run(tokenHash(token),Date.now()+SESSION_DAYS*24*60*60*1000);
  setSessionCookie(res,token); res.json({ok:true});
});
app.post('/api/admin/logout',(req,res)=>{ const t=getCookie(req,'gt_session'); if(t) db.prepare('DELETE FROM sessions WHERE token_hash=?').run(tokenHash(t)); clearSessionCookie(res); res.json({ok:true}); });
app.get('/api/admin/me',requireAdmin,(req,res)=>res.json({ok:true,user:ADMIN_USER}));
app.get('/api/admin/candidates',requireAdmin,(req,res)=>res.json({candidates:publicCandidates()}));

app.post('/api/admin/candidates',requireAdmin,(req,res)=>{
  const name=String(req.body?.name||'').trim(); const number=String(req.body?.number||'').trim(); const party=String(req.body?.party||'').trim(); const photo=String(req.body?.photo||'');
  if(!name || !/^\d{2}$/.test(number)) return res.status(400).json({error:'Informe nome e um número de 2 dígitos.'});
  if(!isSafePhoto(photo)) return res.status(400).json({error:'Foto inválida ou muito grande.'});
  try { const info=db.prepare('INSERT INTO candidates(number,name,party,photo) VALUES(?,?,?,?)').run(number,name,party,photo); res.json({ok:true,id:info.lastInsertRowid}); }
  catch(e){ if(String(e.code||'').includes('SQLITE_CONSTRAINT')) return res.status(409).json({error:'Esse número já está cadastrado.'}); console.error(e); res.status(500).json({error:'Erro ao cadastrar candidato.'}); }
});
app.delete('/api/admin/candidates/:number',requireAdmin,(req,res)=>{
  const number=String(req.params.number); const c=db.prepare('SELECT id FROM candidates WHERE number=?').get(number);
  if(!c) return res.status(404).json({error:'Candidato não encontrado.'});
  const votes=db.prepare('SELECT COUNT(*) AS n FROM votes WHERE candidate_id=?').get(c.id).n;
  if(votes>0) return res.status(409).json({error:'Não é possível excluir um candidato que já recebeu votos. Zere a apuração primeiro.'});
  db.prepare('DELETE FROM candidates WHERE id=?').run(c.id); res.json({ok:true});
});
app.get('/api/admin/results',requireAdmin,(req,res)=>{
  const candidates=db.prepare(`SELECT c.id,c.number,c.name,c.party,c.photo,COUNT(v.id) AS votes FROM candidates c LEFT JOIN votes v ON v.candidate_id=c.id GROUP BY c.id ORDER BY CAST(c.number AS INTEGER)`).all();
  const blank=db.prepare('SELECT COUNT(*) AS n FROM votes WHERE is_blank=1').get().n;
  const total=db.prepare('SELECT COUNT(*) AS n FROM votes').get().n;
  res.json({candidates,blank,total});
});
app.post('/api/admin/reset',requireAdmin,(req,res)=>{ db.prepare('DELETE FROM votes').run(); res.json({ok:true}); });

app.use((req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

app.listen(PORT,()=>console.log(`GT Sistema online em http://localhost:${PORT}`));
